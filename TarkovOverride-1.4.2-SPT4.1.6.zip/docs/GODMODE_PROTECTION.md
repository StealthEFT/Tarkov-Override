# Tarkov Override 1.3.0

Enable Godmode in the Player tab to reveal Protection. Full is the default. Select Custom to show seven immunity checkboxes. Mines count as explosions, and boundary snipers count as bullets. Custom allows damage types you leave unchecked. Your choices are saved.

Enable Demigod to show Health Multiplier immediately below its toggle. Enabling Godmode or Demigod disables the other.